## Fastify Template for Custom Runtime

### Install

```bash
$ npm install
```

### Development

```bash
$ npm run dev
```

### Build

```bash
$ npm run build
```

### Deploy

```bash
$ fun install
# Preview apis with same environment as serverless
$ fun local start Domain
$ fun build
$ fun deploy
```
